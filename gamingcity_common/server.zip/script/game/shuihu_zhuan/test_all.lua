
dofile("test_fullscreen_pattern.lua")

dofile("test_random_pattern.lua")

dofile("test_compare_dice.lua")

dofile("test_bonus_mode.lua")
