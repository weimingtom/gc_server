


print(math.randomseed(1000))
