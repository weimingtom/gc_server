-- demo消息处理

local pb = require "protobuf"

require "game/net_func"
local send2client_pb = send2client_pb

require "game/lobby/base_player"
local base_player = base_player
local room_manager = g_room_manager

function on_cs_texas_action(player, msg)
	local tb = room_manager:find_table_by_player(player)

	if tb then
		local retCode = t:player_action(player, t, msg.action, msg.money)
		if retCode ~= CS_ERR_OK then
			send2client_pb(player,"SC_TexasError", {error=retCode})
		end
	else
		log_error(string.format("guid[%d] give_up", player.guid))
	end
	--t:broadcast2client("SC_TexasU^serAction", ret) 
end

function on_cs_texas_game_state(player, msg)
	local tb = room_manager:find_table_by_player(player)

	if tb then
		tb:game_info(player)
	else
		log_error(string.format("guid[%d] on_cs_texas_game_state", player.guid))
	end
end

--获取坐下玩家
function on_cs_texas_sit_down(player, msg)
	print ("test .................. on_cs_texas_get_sit_down")
	local tb = room_manager:find_table_by_player(player)
	if tb then
		tb:sit_on_chair(player)
	else
		log_error(string.format("guid[%d] get_sit_down", player.guid))
	end
end

-- 玩家离开游戏
function on_cs_texas_leave(player,msg)
	print("test ..................on_cs_texas_leave"..player.guid)
	local tb = room_manager:find_table_by_player(player)
	if tb then
		tb:player_leave(player)
	else
		log_error(string.format("guid[%d] leave ox game error.", player.guid))
	end
end