local pb = require "protobuf"
random = require "utils/random"
tablex = require "utils/tablex"

require "game/lobby/base_table"
require "game/texas/gamelogic"
require "data/texas_data"
require "table_func"

local ITEM_PRICE_TYPE_GOLD = pb.enum_id("ITEM_PRICE_TYPE", "ITEM_PRICE_TYPE_GOLD")
local GAME_SERVER_RESULT_SUCCESS = pb.enum_id("GAME_SERVER_RESULT", "GAME_SERVER_RESULT_SUCCESS")

texas_table = base_table:new()


-- 等待开始
TEXAS_STATUS_WAITING_TIME = 2	--2s
ROUND_THINK_TIME 		= 15

POSITION_LITTLE_BLIND	= 1;--小盲
POSITION_BIG_BLIND 		= 2;--大盲
POSITION_BOTTON			= 3;--庄家
POSITION_NORMAL			= 4;--普通玩家

STATUS_WAITING  	= 1
STATUS_PRE_FLOP 	= 2
STATUS_FLOP 		= 3
STATUS_TURN 		= 4
STATUS_RIVER 		= 5
STATUS_SHOW_DOWN	= 6

--TABLE_STAT_WAITING  = 1	--等待/发牌环节
--TABLE_STAT_BETTING  = 1	--下注环节

PLAYER_STATUS_WAITING	= 0		--等待
PLAYER_STATUS_GAME	= 1
PLAYER_STATUS_ALL_IN	= 2
PLAYER_STATUS_FOLD	= 3

ACT_CALL 	= 1; --跟注
ACT_RAISE 	= 2; --加注
ACT_CHECK 	= 3; --让牌
ACT_FOLD 	= 4; --弃牌
ACT_ALL_IN 	= 5; --全下
ACT_NORMAL 	= 6; --普通
ACT_THINK 	= 7; --牌局轮到此玩家，开始思考的计时状态
ACT_WAITING	= 8; --刚进入的玩家

CS_ERR_OK = 0; 		--正常
CS_ERR_MONEY = 1;   --钱不够
CS_ERR_STATUS = 2;  --状态和阶段不同步错误

LOG_MONEY_OPT_TYPE_TEXAS = 12;
-- TABLE_STAT_WAITING  = 1	--等待/发牌环节
-- TABLE_STAT_BETTING  = 1	--下注环节

-- 心跳
function texas_table:tick()
	if self.t_status == STATUS_WAITING then
		--发牌
		local len = 0
	 	for k, p in pairs(self.t_player) do
	        if p then
	            len = len +1
	        end
	    end
	    if len > 1 then
			self:distribute_cards()
		end
	elseif self.t_status == STATUS_SHOW_DOWN then
		--结算
		self:show_down_and_award()
	else
		--游戏状态
		self:start_game()
	end
end


function texas_table:init_load_texas_config_file()	
 	package.loaded["data/texas_data"] = nil 
	require "data/texas_data"
end

function texas_table:load_texas_config_file()
	TEXAS_FreeTime = texas_room_config.Texas_FreeTime
	--print("BetTime = "..OX_TIME_ADD_SCORE)
end

--重置
function texas_table:reset(room, table_id, chair_count)
	base_table.init(self, room, table_id, chair_count)
	self.t_status = STATUS_WAITING
	--self.t_status_table = TABLE_STAT_BETTING
	self.blind_small_bet = 10
	self.blind_big_bet = self.blind_small_bet * 2
	self.t_pot = 0		--主池
	self.t_cur_side_pot = {}
	self.think_time = ROUND_THINK_TIME
	self.t_pot_player = {}	-- to load from config
	self.t_public_cards = {}
	self.t_player = {}
	self.t_min_bet = 10		--read from config
	self.t_max_bet = 10000	--read from config
	self.t_bet = {}
	self.t_cur_pot = 0
	self.t_cur_max_bet = 0
	self.t_active_player = {guid = 0,chair = 0,max_bet = 0,min_bet = 0,action = 0}
	self.player_count = 0
	--self.t_botton = {}
	
	-- self.player_list = {}
--[[	for i = 1, chair_count do
		self.player_list[i] = {}
	end--]]

	self.side_pot = {}
	for i = 1,7 do
		table.insert(self.side_pot,{})
	end
end

-- 初始化
function texas_table:init(room, table_id, chair_count)
	base_table.init(self, room, table_id, chair_count)

	self.t_card_set = {
		0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,	--方块 A - K
		0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1A,0x1B,0x1C,0x1D,	--梅花 A - K
		0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,0x2A,0x2B,0x2C,0x2D,	--红桃 A - K
		0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B,0x3C,0x3D,	--黑桃 A - K
	}
	self:reset(room, table_id, chair_count)
	self:init_load_texas_config_file()
	self:load_texas_config_file()
	--测试
--[[	self.t_bet[10] = {10,20,30,0,0,0,0}
	self.t_bet[20] = {10,20,30,40,0,0,0}
	self.t_bet[30] = {10,20,30,35,0,0,0}
	self.t_bet[40] = {10,20,30,12,0,0,0}
	self.t_bet[50] = {10,20,30,45,0,0,0}
	self.t_bet[60] = {10,20,30,45,50,0,0}
	
	self:add_pool(10,30,3)
	self:add_pool(20,40,4)
	self:add_pool(40,12,4)
	self:add_pool(30,35,4)
	self:cal_side_pot()--]]
	
end


function texas_table:distribute_cards()
	self.t_status = STATUS_PRE_FLOP
	self.t_round = 1
	local user_cards_idx = 0
	
	--5张公共牌
	for i = 0,4 do
		user_cards_idx = user_cards_idx + i
		local idx = random.integer(1,#self.t_card_set - user_cards_idx)
		local card = self.t_card_set[idx]

		table.insert(self.t_public_cards, card)
		self.t_card_set[idx] = self.t_card_set[#self.t_card_set - user_cards_idx]
		self.t_card_set[#self.t_card_set - user_cards_idx] = card
	end

	--每个准备的玩家2张底牌 
	local notify = {}
	notify.pb_talbe = {}
	notify.pb_talbe.state = STATUS_PRE_FLOP

	for _guid, p in pairs(self.t_player) do
		local _chari = p.chair
		local player = self:get_player(p.chair)
		
		--选出两张牌发给玩家
		local l_user_cards = {}
		for i = 0,1 do
			user_cards_idx = user_cards_idx + i
			local idx = random.integer(1,#self.t_card_set - user_cards_idx)
			local card = self.t_card_set[idx]
			table.insert(l_user_cards,card)
			self.t_card_set[idx] = self.t_card_set[#self.t_card_set - user_cards_idx]
			self.t_card_set[#self.t_card_set - user_cards_idx] = card
		end

		self.t_player[_guid] = {
			chair = p.chair,
			cards = l_user_cards,
			status = PLAYER_STATUS_GAME
		}

		local v = {
			guid = _guid,
			chair = p.chair,
			money = player:get_money(),
			hole_cards = 1,
			bet_money = self.t_bet[_guid],
			countdown = 0,
			win_money = 0,
			main_pot_money = 0
		}
		
		notify.pb_usr = notify.pb_usr or {}
		table.insert(notify.pb_usr, v)
		
		self.player_count = self.player_count + 1
	end
	
	--发给每个人(加上自己的底牌)
 	for _guid,p in pairs(self.t_player) do
		local msg = notify
		msg.pb_usr.cards = self.t_player[_guid].cards
		local player = self:get_player(p.chair)

		send2client_pb(player,"SC_TexasSendUserCards", msg)
	end
	
	
	self:set_botton_and_blind()

	local l_small_bind = self:get_small_blind()
	--当前说话玩家
	self.t_active_player.chair = l_small_bind.chair
	self.t_active_player.guid = l_small_bind.guid

	--扣除大小盲注
	self.t_next_player = self:get_big_blind()
	--if not self.t_next_player then self.t_next_player = self:get_small_blind()

	--扣除小盲注,底注
	local player = self:get_player(l_small_bind.chair)
	self:add_bet(player, self.blind_small_bet)
	
	--扣除大盲注，2倍底注
	player = self:get_player(self.t_next_player.chair)
	self.t_cur_max_bet = self.blind_big_bet
	self:add_bet(player, self.blind_big_bet)
	--设置当前最大注数

	--生产下位说话玩家
	--self:set_next_active_player()
	
	--清除准备状态进入游戏  base_table:clear_ready()
	--self:clear_ready()
	self.t_timer = get_second_time() + ROUND_THINK_TIME
end


-- 检查是否可准备
function texas_table:check_ready(player)
	return (self.t_status == STATUS_WAITING and self.ready and player and player:get_money() >= self.blind_big_bet) and true or false
end

--game
function texas_table:start_game()
	if self:check_next_round() then
		--下一阶段切换准备
		self.t_status = self.t_status + 1
		self.t_round = self.t_round + 1
		self.t_cur_max_bet = 0
		self.t_cur_pot = 0
		--checked
		--公共展示牌 self.t_public_show = self.t_public_cards
		if self.t_status > STATUS_PRE_FLOP and self.t_status < STATUS_SHOW_DOWN then
			self.t_public_show = {}
			for i = 1, self.t_status do
				table.insert(self.t_public_show, self.t_public_cards[i])
			end

			--sendToAll public cards
			local msg = {}
			msg.talbe = {
				state = self.t_status,
				public_cards = self.t_public_show
			}
			msg.public_cards = self.t_public_show
			self:broadcast2client("SC_TexasSendPublicCards",msg)
		end

		--第一个行动 小盲注玩家
		self.t_next_player = self:get_small_blind()
		self.check_count = 0
		self.player_count = 0

		--统计当前阶段进入游戏的玩家 (非离线/等待)
		for k,v in pairs(self.t_player) do
			if v.status == PLAYER_STATUS_GAME	--checked !!
			then 
				self.player_count = self.player_count + 1
			end
		end
	else
		--押注切换   超时/玩家等待中/离线
		if 0 and self.t_timer < get_second_time() or self.t_active_player.guid == 0 
			or self.t_player[self.t_active_player.guid].status ~= PLAYER_STATUS_GAME 
		then
			self:cur_active_player()
			self:set_next_active_player()
		end
	end
end


--确定庄家，盲位
function texas_table:set_botton_and_blind()
	if self.t_botton == nil then	--or self.t_botton.chair == 0
		local l_player = nil
		self.t_botton = {}
		for k, v in pairs(self.t_player) do
			l_player = self:get_player(v.chair)
			if l_player then
				self.t_botton.chair = v.chair
				self.t_botton.guid = k
				break
			end
		end
	else
		local l_chair = self.t_botton.chair
		for i = 1,7 do
			l_chair = self.t_botton.chair + i
			l_chair = l_chair > 7 and l_chair - 1 or l_chair
			local l_player = self:get_player(l_chair)
			if l_player and self.t_player[l_player.guid] then
				self.t_botton = {chair = l_chair, guid = l_player.guid}
				break
			end
		end
	end

	--大小盲位
	self.t_blind = {}
	for i = 1,7 do
		l_chair = self.t_botton.chair + i
		l_chair = l_chair > 7 and l_chair - 7 or l_chair
		local l_player = self:get_player(l_chair)
		if l_player and self.t_player[l_player.guid] then --and self.t_botton_guid ~= l_player.guid
			table.insert(self.t_blind, 
				{
					guid = l_player.guid, 
					chair = l_chair
				}
			)
		end
		
		if #self.t_blind >= 2 then
			break
		end
	end
end

--获取小盲位
function texas_table:get_small_blind()
	if self.t_blind[1] then
		return self.t_blind[1]
	end
	return nil
end

--获取大盲位
function texas_table:get_big_blind()
	if self.t_blind[2] then
		return self.t_blind[2]
	end
	return nil
end

--进入下一轮
function texas_table:cur_active_player()
	--checked!!
	if self.t_player[self.t_next_player.guid].status ~= PLAYER_STATUS_GAME then
		self.t_timer = 0
		return
	end
	
	self.t_timer = get_second_time() + ROUND_THINK_TIME

	--checked
	if self.t_active_player and self.t_active_player.guid and 
		self.t_active_player.guid ~= 0 --and ~self.t_player[self.t_active_player.guid]
	then
		--checked !!   如果当前玩家本轮已下注筹码，小于本轮桌上评价每一份筹码，弃牌
		if self.t_bet[self.t_active_player.guid][self.t_round] == self.t_cur_max_bet then 
		--self.t_active_player.action & ACT_CHECK
			self.t_player[self.t_active_player.guid].action = ACT_CHECK
			self.t_player[self.t_active_player.guid].status = PLAYER_STATUS_CHECK

			--超时让牌
			--local ret = {action = ACT_CHECK,err = pb.enum_id("SC_TexasAction.Error","OK"),guid = self.t_active_player.guid}
			--self:broadcast2client("SC_TexasAction",ret)

			self.check_count = self.check_count + 1
			local msg = {
				chair = t_active_player.chair,
				action = ACT_CHECK,
			}

			self:broadcast2client("SC_TexasAction",msg)
		else
			self.t_player[self.t_active_player.guid].action = ACT_FOLD
			self.t_player[self.t_active_player.guid].status = PLAYER_STATUS_FOLD
			--超时弃牌
			--local ret = {action = ACT_FOLD,err = pb.enum_id("SC_TexasAction.Error","OK"),guid = self.t_active_player.guid}

			local msg = {
				chair = t_active_player.chair,
				action = ACT_FOLD
			}
			self:broadcast2client("SC_TexasAction",ret)
		end
	end
	
	self.t_active_player.guid = self.t_next_player.guid
	self.t_active_player.chair = self.t_next_player.chair
	self.t_player[self.t_active_player.guid].action = 0
	
	--确定动作
	-- to be check!!
	--给客户端端计算可以使用的动作
	-- self.t_active_player.action = ACT_CALL|ACT_RAISE|ACT_FOLD|ACT_ALL
	-- if #self.t_public_show >= 3 and self.t_cur_max_bet == 0 then
	-- 	--发公牌后，如果没下注都可以选择让牌
	-- 	self.t_active_player.action = ACT_RAISE|ACT_CHECK|ACT_FOLD|ACT_ALL
	-- end

	--确定下注上下限
	if self.t_cur_max_bet == 0 then
		self.t_active_player.min_bet = self.blind_big_bet
	else
		--本轮最小下注 = 本轮最大下注 - 本轮玩家已下注
		self.t_active_player.min_bet = self.t_cur_max_bet - self.t_bet[self.t_active_player.guid][self.t_round]
	end

	self.t_active_player.max_bet = self.t_cur_pot	--当前底池金额

	--给客户端端计算可以使用的动作
	-- if player:get_money() <= self.t_active_player.max_bet then
	-- 	self.t_active_player.action = self.t_active_player.action|ACT_ALL
	-- elseif player:get_money() < self.t_active_player.min_bet then
	-- 	self.t_active_player.action = ACT_FOLD|ACT_ALL
	-- end

	--同步游戏数据
	local msg = {}
	msg.state = self.t_status
	msg.guid = self.t_active_player.guid
	--msg.action = self.t_active_player.action
	msg.max_bet = self.t_active_player.max_bet
	msg.min_bet = self.t_active_player.min_bet
	msg.timer = self.t_timer - get_second_time()
	msg.public_cards = self.t_public_show
	msg.blind_bet = self.blind_big_bet
	--msg.blind_big = self:get_big_blind() and self:get_big_blind().guid or 0
	--msg.blind_small = self:get_small_blind() and self:get_small_blind().guid or 0
	--msg.banker = self.t_botton.guid
	--计算边池

	--msg.pool = self.t_cur_side_pot
	for i = 1,7 do
		msg.cards = {}
		msg.user.cards_type = 0
	
		local player = self:get_player(i)
		if player then
			if self.t_player[player.guid] then
				msg.cards = tablex.copy(self.t_player[player.guid].cards)
				
				--给客户端端计牌型
				if #self.t_public_show == 3 then
					local cards = tablex.copy(msg.cards)
					for k,v in ipairs(self.t_public_show) do
						table.insert(table,v)
					end
					msg.user.cards_type = t_get_card_type(cards)
				elseif #self.t_public_show == 4 then
					msg.user.cards_type = t_get_type_five_from_six(msg.cards,self.t_public_show)
				elseif #self.t_public_show == 5 then
					msg.user.cards_type = t_get_type_five_from_seven(msg.cards,self.t_public_show)
				end
			end


			send2client_pb(player,"SC_TexasTableInfo",msg)
		end
	end
end

--设置下一个说话玩家
function texas_table:set_next_active_player()
	local l_chair = self.t_active_player.chair
	for i = 1,7 do
		l_chair = self.t_active_player.chair + i
		if l_chair > 7 then
			l_chair = l_chair - 7
		end

		local player = self:get_player(l_chair)
		if player and self.t_player[player.guid] and 
			self.t_player[player.guid].status == PLAYER_STATUS_GAME 
		then
			self.t_next_player = {
				guid = player.guid,
				chair = l_chair
			}
			return
		end
	end
end

--检查是否进入下一阶段
function texas_table:check_next_round()
	if self.t_status == STATUS_WAITING or self.t_status == STATUS_SHOW_DOWN then
		return false
	end

	--检查是否所有玩家下注的钱 是否等于最大下注
	for k,v in pairs(self.t_player) do
		if v.status == PLAYER_STATUS_GAME then
			if self.t_cur_max_bet ~= self.t_bet[k][self.t_round] then
				return false
			end
		end
	end

	--让/过牌未满一轮
	--check
	if self.t_cur_max_bet == 0 and self.player_count ~= self.check_count then
		return false
	end

	if self.t_status == STATUS_RIVER then 
		self.t_status = STATUS_SHOW_DOWN
	end 

	return true
end

--结算
function texas_table:show_down_and_award()
	--发放奖励
	self:cal_side_pot()
	--同步游戏数据
	local msg = {}
	msg.state = self.t_status
	msg.timer = self.t_timer - get_second_time()
	msg.public_cards = self.t_public_show
	msg.pot = self.t_pot

	--计算边池 checked!
	msg.pool = self.t_cur_side_pot

	local l_players = {}
	for i = 1,7 do
		local player = self:get_player(i)
		if player then
			msg.cards = {}
			local luser = {
				chair = i,
				guid = player.guid,
				cards_type = 0,
				action = t_player_cards[player.guid].status
			}

			if self.t_player[player.guid] then
				msg.cards = tablex.copy(self.t_player[player.guid].cards)
				
				if #self.t_public_show == 3 then
					local cards = tablex.copy(msg.cards)
					for k,v in ipairs(self.t_public_show) do
						table.insert(table,v)
					end
					luser.cards_type = t_get_card_type(cards)
				elseif #self.t_public_show == 4 then
					luser.cards_type = t_get_type_five_from_six(msg.cards,self.t_public_show)
				elseif #self.t_public_show == 5 then
					luser.cards_type = t_get_type_five_from_seven(msg.cards,self.t_public_show)
				end
			end
			
			l_players[player.guid] = luser;
			--send2client_pb(player,"SC_TexasGame",msg)
		end
	end

	--结算
	for i,j in pairs(self.t_side_pot) do
		local user = {}
		local get_money = 0
		for guid, v in pairs(self.t_side_pot[i]) do
			if self.t_player[guid] and self.t_player[guid].status ~= PLAYER_STATUS_FOLD then
				local info = {guid = guid, card_type = 0,cards = {}}
				info.card_type, info.cards = t_get_type_five_from_seven(self.t_player[guid].cards,self.t_public_cards)
				table.insert(user, info)
			end
			get_money = get_money + v
		end

		--结算当前边池的奖金
		local l_card_type, win_array = get_win_player(user)
		if win_array then
			get_money = math.floor(get_money / #win_array)
			for k, _guid in ipairs(win_array) do
				local player = self:get_player(self.t_player[_guid].chair)
				if player then
					player:add_money({{money_type = ITEM_PRICE_TYPE_GOLD, money = get_money}}, LOG_MONEY_OPT_TYPE_TEXAS)
					--self:broadcast2client("SC_TexasEnd",{guid = v,money = get_money,type = l_card_type,cards = tablex.copy(self.t_player[player.guid].cards)})
				end
			end
		end
	end

	for id, val in pairs(l_players) do
		msg.user = msg.user or {}
		table.insert(msg.user, val)
	end

	self:broadcast2client("SC_TexasTableEnd", msg)
	--重置
	self:reset()
end

--玩家下注
function texas_table:add_bet(player, money)
	if not player or player:get_money() < money then
		return false
	end

	player:cost_money(
		{{money_type = ITEM_PRICE_TYPE_GOLD, money = money}}, 
		LOG_MONEY_OPT_TYPE_TEXAS
	)

	--to be check!!!	
	--当前轮次底池金额
	self.t_cur_pot = self.t_cur_pot + money
	self.t_pot = self.t_pot + money

	self.t_bet[player.guid][self.t_round] = self.t_bet[player.guid][self.t_round] + money

	--当前最大注
	self.t_cur_max_bet = 
		self.t_bet[player.guid][self.t_round] > self.t_cur_max_bet and 
		self.t_bet[player.guid][self.t_round] or self.t_cur_max_bet
	
	--记录边池产生者
	if player:get_money() == 0 then
		--table.insert(self.t_side_pot_players,{guid = player.guid,money = self.t_bet[player.guid][self.t_round],idx = self.t_round})
		self:add_pool(player.guid, self.t_bet[player.guid][self.t_round], self.t_round)
	end
	return true
end

--计算边池
function texas_table:cal_side_pot()
	self.t_side_pot = {}
	local except_money = 0
	local money = 0

	for l_guid, v_usr in pairs(self.t_side_pot_players) do
		for guid, l_bet in pairs(self.t_bet) do
			if l_bet[v_usr.idx] > 0 then
				money = 0
				for i = 1,v_usr.idx - 1 do
					money = money + l_bet[i]
			 	end

				if l_bet[v_usr.idx] > v_usr.money then
					money = money + v_usr.money
				else
					money = money + l_bet[v_usr.idx]
				end

				money = money - except_money
				if money > 0 then
					self.t_side_pot[self.idx][guid] = money
				end
			end
		end

		except_money = except_money + self.t_side_pot[self.idx][v_usr.guid]
		self.idx = self.idx + 1
	end

	for guid, l_bet in pairs(self.t_bet) do
		money = 0
		for k,v in pairs(l_bet) do
			money = money + v
		end

		money = money - except_money
		if money > 0 then
			self.t_side_pot[self.idx][guid] = money
		end
	end

	--更新当前边池
	self.t_cur_side_pot = {}
	for k,v in pairs(self.t_side_pot) do
		local money = 0
		for _,value in pairs(v) do
			money = money + value
		end
		if money > 0 then
			table.insert(self.t_cur_side_pot,money)
		end
	end
end

--增加边池记录
function texas_table:add_pool(guid,money,round)
	local l_insert = 1
	for k, val in pairs(self.t_side_pot_players) do
		l_insert = k + 1
		if v.idx == round and v.money > money then
			l_insert = k
			break
		end
	end

	table.insert(
		self.t_side_pot_players,
		l_insert,
		{guid = guid,money = money,idx = round}
	)
end

--动作处理
function texas_table:player_action(player, talbeInstance, action, money)
	if self.t_active_player.guid ~= player.guid then
		return CS_ERR_STATUS
	end

	local l_money = msg.money and msg.money or 0
	local ret = {
		chair = player.chair_id,
		action = msg.action
	}

	if l_money then
		self.t_pot = self.t_pot + l_money
		ret.bet_money = l_money
		ret.table = {
			pot = self.t_pot
		}
		--sidepot wait to add
	end

	if action == ACT_CHECK then
		if self.t_cur_max_bet ~= 0 then
			return CS_ERR_STATUS
		end
		self.check_count = self.check_count + 1
	elseif action == ACT_FOLD then
		self.t_player[player.guid].status = PLAYER_STATUS_FOLD
		--if check_action(self.t_active_player.action&ACT_CHECK) then self.check_count = self.check_count + 1
	elseif action == ACT_BET or action == ACT_ALL then
		if action == ACT_ALL or player:get_money() == 0 then
			money = player:get_money()
			self.t_active_player.max_bet = money
			self.t_player[player.guid].status = PLAYER_STATUS_ALL_IN
		end

		if money > player:get_money() or money > self.t_active_player.max_bet or money < self.t_active_player.min_bet then
			return CS_ERR_MONEY
		end

		self:add_bet(player, money)
	end

	self.t_player[player.guid].action = action
	self.t_timer = 0

	talbeInstance:broadcast2client("SC_TexasUserAction", ret) 
	return CS_ERR_OK
end


--亮牌
function texas_table:show_cards(player)
	if self.t_status ~= STATUS_WAITING or self.t_player[player.guid] == nil then
		return
	end
	self:broadcast2client("SC_TexasShowCards",{guid = player.guid,cards = tablex.copy(self.t_player[player.guid].cards)})
end

--打赏荷官
function texas_table:reward_dealer(player)
	self:broadcast2client("SC_TexasReward",{guid = player.guid})
end

-- 进入房间并坐下
function texas_table:do_sit_down(player, tb)
	local notify = {}
	notify.pb_user = {}
	notify.pb_table = {
		state = self.t_status,
		min_bet = self.t_min_bet,
		max_bet	= self.t_max_bet,
		blind_bet = self.blind_small_bet,
		pot = self.t_pot,
		side_pot = self.t_cur_side_pot,
		think_time = 15,
		public_cards = self.t_public_show,
		own_chair = player.chair_id
	}

	local newPlayerVal = {
		chair = player.chair_id,
		guid = player.guid,
		icon =  player:get_header_icon(),
		name = player.nickname,
		money = player:get_money(),
		bet_money = 0,
		action = ACT_WAITING,
		position = POSITION_NORMAL,
		hole_cards = 0,
		--cards = {},
		countdown = 0,
		victory = 3,
		win_money = 0,
		main_pot_money = 0
	}

	--遍历桌上其它玩家的数据
	tb:foreach_except(player.chair_id, function (p)
		local l_action = self.t_player[p.guid].action
		local l_hole_cards = 1
		if l_action == ACT_FOLD or l_action == ACT_WAITING then
			l_hole_cards = 0
		end
		
		local v = {
			chair = p.chair_id,
			guid = p.guid,
			icon =  p:get_header_icon(),
			name = p.nickname,
			money = p:get_money(),
			bet_money = self.t_bet[p.guid],
			position = p.position,
			action = l_action,
	 		hole_cards = l_hole_cards,
			icon = p:get_header_icon(),
			cards = self.t_player.cards,
			countdown = 0,
			victory = 3,
			biggest_winner = 2,
			win_money = 0,
			main_pot_money = 0
		}
		notify.pb_user = notify.pb_user or {}
		table.insert(notify.pb_user, v)

		send2client_pb(p, "SC_TexasNewUser", {pb_user = newPlayerVal})
	end)
	

	notify.pb_user = notify.pb_user or {}
	table.insert(notify.pb_user, newPlayerVal)
	send2client_pb(player, "SC_TexasTableInfo", notify)
end

--玩家站起离开房间
function texas_table:player_stand_up(player, is_offline)
	print("STAND_UPPPP AAAAAAAAAAAAAAAAAAZZZZZZZZZZZZZZZZZZZZzzzzzzzzzzzzzzzzzz!!!!!!!!" ,player.chair_id, is_offline)	
	print("base_table.player_stand_up(self,player,is_offline)")
    print(player.table_id,player.chair_id,player.guid)

    base_table.player_stand_up(self,player,is_offline)
    self.room_:player_exit_room(player)
end

--玩家坐下、初始化
function texas_table:player_sit_down(player, chair_id_)
	print("---------------texas_table player_sit_down  -----------------", chair_id_)
	for i,v in pairs(self.player_list_) do
		if v == player then
			player.chari_id_ = v.chari_id_
			player:on_stand_up(self.table_id_, chari_id_, GAME_SERVER_RESULT_SUCCESS)
			return
		end
	end

	self.t_player[player.guid] = {
		chair = chair_id_,
		cards = {},
		status = PLAYER_STATUS_WAITING,
		action = ACT_WAITING
	}
	self.t_bet[player.guid] = {0,0,0,0,0,0,0}
	

	player.table_id = self.table_id_
	player.chair_id = chair_id_
	player.room_id = self.room_.id
	self.player_list_[chair_id_] = player
end


function texas_table:reconnect(player)
	print("texas_table:reconnect~~~~~~~~~~~~~~~~~~!!!!!!!!!!!!!!!!",player.chair_id)
	for i,v in ipairs(self.player_list_) do
		if v then
			print (v.chair_id)
			print (v, player)
			if v == player then
				print("---------- reconnect~~~~~~~~~!")
				--send2client_pb(player, "SC_ZhaJinHuaReConnect", msg)
				player.table_id = self.table_id_
				player.room_id = self.room_.id

				--table.insert(self.gamelog.offlinePlayers, offline)	
				return
			end
		end
	end
	
	--send2client_pb(player, "SC_ZhaJinHuaReConnect", msg)
	return
end

function texas_table:sit_on_chair(player)
	print ("get_sit_down-----------------  texase   ----------------")
	--self.player_online[player.chair_id] = true
	local result_, table_id_, chair_id_ = base_room_manager.sit_down(self, player, self.table_id_, player.chair_id)

	print ("player.room_id_, player.table_id_, player.chair_id",self.room_.id, self.table_id_, player.chair_id)
	self:do_sit_down(player, self)
	--player, self.room_.id, self.table_id_, player.chair_id, GAME_SERVER_RESULT_SUCCESS, self
end


function texas_table:player_leave(player)
	print ("player_leave-----------------  texase   ----------------")
	--self.player_online[player.chair_id] = true
	print ("player.room_id_, player.table_id_, player.chair_id",self.room_.id, self.table_id_, player.chair_id)
	--player, self.room_.id, self.table_id_, player.chair_id, GAME_SERVER_RESULT_SUCCESS, self
	self.t_player[player.guid] = {}
end

