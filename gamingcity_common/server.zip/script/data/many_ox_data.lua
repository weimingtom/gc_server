many_ox_room_config = {
	[1] = { Ox_FreeTime = 3, --�߱���
			Ox_BetTime = 18,
			Ox_EndTime = 15,
			Ox_MustWinCoeff = 5,
			Ox_FloatingCoeff = 3,
			Ox_bankerMoneyLimit = 1000000,
			Ox_SystemBankerSwitch = 1,
			Ox_BankerCount = 5,
			Ox_RobotBankerInitUid = 500000,
			Ox_RobotBankerInitMoney = 10000000,
			Ox_BetRobotSwitch = 1,
			Ox_BetRobotInitUid = 600000,
			Ox_BetRobotInitMoney = 35000,
			Ox_BetRobotNumControl = 5,
			Ox_BetRobotTimeControl = 10,
			Ox_RobotBetMoneyControl = 10000,
			Ox_basic_chip = {100,1000,5000,10000,50000}},
	[2] = {	Ox_FreeTime = 3, --�ͱ���
			Ox_BetTime = 18,
			Ox_EndTime = 15,
			Ox_MustWinCoeff = 5,
			Ox_FloatingCoeff = 3,
			Ox_bankerMoneyLimit = 300000,
			Ox_SystemBankerSwitch = 1,
			Ox_BankerCount = 5,
			Ox_RobotBankerInitUid = 700000,
			Ox_RobotBankerInitMoney = 10000000,
			Ox_BetRobotSwitch = 1,
			Ox_BetRobotInitUid = 800000,
			Ox_BetRobotInitMoney = 15000,
			Ox_BetRobotNumControl = 5,
			Ox_BetRobotTimeControl = 10,
			Ox_RobotBetMoneyControl = 10000,
			Ox_basic_chip = {10,100,500,1000,5000}}
}












