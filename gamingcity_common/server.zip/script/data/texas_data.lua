texas_room_config = {
	Texas_FreeTime = 3,
}