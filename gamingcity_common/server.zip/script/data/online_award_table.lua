-- 在线奖励

online_award_table = {
	{cd = 60*1, money = 500},
	{cd = 60*5, money = 1000},
	{cd = 60*10, money = 1500},
	{cd = 60*15, money = 2000},
	{cd = 60*20, money = 2500},
	{cd = 60*30, money = 3000},
	{cd = 60*30, money = 3500},
	{cd = 60*30, money = 4000},
	{cd = 60*30, money = 4500},
	{cd = 60*30, money = 5000},
}

